function somar(){
    let n1 = parseInt(document.getElementById("valor1").value)
    let n2 = parseInt(document.getElementById("valor2").value)

    let soma = n1 + n2
    document.getElementById("resultado").textContent = soma 
}